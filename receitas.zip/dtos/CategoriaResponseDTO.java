package com.puc.bancodedados.receitas.dtos;

public record CategoriaResponseDTO(
        Long id,
        String nomeCategoria
) {
}
